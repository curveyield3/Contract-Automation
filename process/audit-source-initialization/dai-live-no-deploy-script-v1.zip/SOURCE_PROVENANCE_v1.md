# DAI live-source verification input v1

Etherscan target: https://etherscan.io/address/0x6b175474e89094c44da98b954eedeac495271d0f#code
Compiler: 0.5.12; optimizer disabled, 200 runs (Etherscan indexed record).
Source recovered through GitHub connector from sky-ecosystem/dss commit 6fa55812a5fcfcfa325ad4d9a4d0ca4033c38cab, src/dai.sol and src/lib.sol.
This is a candidate source binding. The live runner must verify bytecode and reject any mismatch; this file does not claim verification.
No deployment script is supplied or required in LIVE mode.
