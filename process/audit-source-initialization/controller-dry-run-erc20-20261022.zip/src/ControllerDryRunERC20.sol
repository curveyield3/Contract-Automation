// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @notice Minimal unprivileged ERC20 for a controller lifecycle dry run.
contract ControllerDryRunERC20 {
    string public constant name = "Controller Dry Run";
    string public constant symbol = "CDRY";
    uint8 public constant decimals = 18;
    uint256 public totalSupply;
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;
    event Transfer(address indexed from, address indexed to, uint256 amount);
    event Approval(address indexed owner, address indexed spender, uint256 amount);
    constructor(uint256 amount) {
        totalSupply = amount;
        balanceOf[msg.sender] = amount;
        emit Transfer(address(0), msg.sender, amount);
    }
    function transfer(address to, uint256 amount) external returns (bool) {
        _move(msg.sender, to, amount);
        return true;
    }
    function approve(address spender, uint256 amount) external returns (bool) {
        allowance[msg.sender][spender] = amount;
        emit Approval(msg.sender, spender, amount);
        return true;
    }
    function transferFrom(address from, address to, uint256 amount) external returns (bool) {
        uint256 authorized = allowance[from][msg.sender];
        require(authorized >= amount, "allowance");
        unchecked { allowance[from][msg.sender] = authorized - amount; }
        emit Approval(from, msg.sender, allowance[from][msg.sender]);
        _move(from, to, amount);
        return true;
    }
    function _move(address from, address to, uint256 amount) internal {
        require(to != address(0), "zero recipient");
        uint256 balance = balanceOf[from];
        require(balance >= amount, "balance");
        unchecked { balanceOf[from] = balance - amount; }
        balanceOf[to] += amount;
        emit Transfer(from, to, amount);
    }
}
