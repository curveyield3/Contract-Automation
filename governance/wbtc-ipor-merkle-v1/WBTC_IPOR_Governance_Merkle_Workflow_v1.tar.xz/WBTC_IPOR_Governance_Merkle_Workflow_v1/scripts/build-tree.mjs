import fs from 'node:fs';
import { getAddress } from 'ethers';
import { StandardMerkleTree } from '@openzeppelin/merkle-tree';

const snapshot = JSON.parse(fs.readFileSync('output/snapshot.json','utf8'));
const safe = getAddress(snapshot.safe);
const registrySeen = new Set();
let base = 0n;
const rows = [];
for (const v of snapshot.voters) {
  const address = getAddress(v.user);
  if (address === safe) throw new Error('Safe incorrectly appears in community roster');
  if (registrySeen.has(address)) throw new Error('Duplicate voter');
  registrySeen.add(address);
  const direct = BigInt(v.direct);
  const morpho = v.morpho.reduce((a,b)=>a+BigInt(b),0n);
  const curve = v.curve.reduce((a,b)=>a+BigInt(b),0n);
  const expected = v.eligible ? direct + morpho + curve : 0n;
  if (expected !== BigInt(v.baseWeight)) throw new Error(`Inconsistent base weight for ${address}`);
  base += expected;
  rows.push({address,baseWeight:String(expected),weight:String(expected*85n),eligible:!!v.eligible});
}
// Exact 15% voting weight in integer arithmetic; no 15/85 rounding.
const safeWeight = base*15n;
rows.push({address:safe,baseWeight:'0',weight:String(safeWeight),eligible:true,safe:true});
const totalWeight = base*100n;
if (rows.reduce((a,r)=>a+BigInt(r.weight),0n)!==totalWeight) throw new Error('Total weights mismatch');
rows.sort((a,b)=>a.address.toLowerCase().localeCompare(b.address.toLowerCase()));
const types = ['uint256','address','uint256','uint256','address','uint256'];
const leaves = rows.map(r=>[
  snapshot.chainId, snapshot.dao, snapshot.proposalId, String(snapshot.snapshotBlock),r.address,r.weight
]);
const tree=StandardMerkleTree.of(leaves,types);
const manifest={
  schemaVersion:1, chainId:snapshot.chainId,dao:snapshot.dao,proposalId:snapshot.proposalId,
  snapshotBlock:snapshot.snapshotBlock,snapshotBlockHash:snapshot.snapshotBlockHash,
  configHash:snapshot.configHash, safe, merkleRoot:tree.root,
  communityBaseWeight:String(base),safeWeight:String(safeWeight),totalVotingWeight:String(totalWeight),
  eligibleVoters:rows.filter(r=>r.eligible&&!r.safe).length,
  includedRegisteredVoters:rows.length-1,leafCount:rows.length,
  leafTypes:types
};
fs.writeFileSync('output/manifest.json',JSON.stringify(manifest,null,2)+'\n');
fs.writeFileSync('output/tree.json',JSON.stringify(tree.dump(),null,2)+'\n');
const proofs={};
for(let i=0;i<rows.length;i++){
  proofs[rows[i].address]={weight:rows[i].weight,leafValues:leaves[i],proof:tree.getProof(i)};
}
fs.writeFileSync('output/voter-proofs.json',JSON.stringify(proofs,null,2)+'\n');
console.log(`Merkle root ${tree.root}; total active weight ${totalWeight}`);
