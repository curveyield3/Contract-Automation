import fs from 'node:fs';
import crypto from 'node:crypto';
import { AbiCoder, Contract, Interface, JsonRpcProvider, getAddress, getBytes } from 'ethers';

const readJSON=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const config=readJSON(process.env.CONFIG_PATH||'config/protocol.json');
const manifest=readJSON('output/manifest.json');
const receipt=readJSON('output/receipt.json');
const rpc=process.env.ETH_RPC_URL;
if(!rpc) throw new Error('ETH_RPC_URL required');
if(!/^0x[0-9a-fA-F]{64}$/.test(receipt.imageId)||!/^0x[0-9a-fA-F]{64}$/.test(config.expectedImageId)) throw new Error('Invalid image ID');
if(receipt.imageId.toLowerCase()!==config.expectedImageId.toLowerCase()) throw new Error('ZK guest program ID not allowlisted');
if(!/^0x(?:[0-9a-fA-F]{2})+$/.test(receipt.seal)||!/^0x(?:[0-9a-fA-F]{2})+$/.test(receipt.journal)) throw new Error('Missing proof seal or journal');
// The journal is ABI-encoded by the RISC Zero guest; it is public, authenticated output.
const types=['uint256','address','uint256','uint256','bytes32','bytes32','bytes32','uint256','uint256','address','uint256'];
const output=AbiCoder.defaultAbiCoder().decode(types,receipt.journal);
const expected=[
  manifest.chainId,manifest.dao,manifest.proposalId,String(manifest.snapshotBlock),
  manifest.snapshotBlockHash,manifest.configHash,manifest.merkleRoot,
  manifest.totalVotingWeight,manifest.communityBaseWeight,manifest.safe,manifest.safeWeight
];
for(let i=0;i<types.length;i++){
  const observed=types[i]==='address'?getAddress(output[i]):String(output[i]).toLowerCase();
  const desired=types[i]==='address'?getAddress(expected[i]):String(expected[i]).toLowerCase();
  if(observed!==desired) throw new Error(`Proof journal field ${i} does not match Merkle manifest`);
}
const journalDigest='0x'+crypto.createHash('sha256').update(getBytes(receipt.journal)).digest('hex');
const provider=new JsonRpcProvider(rpc);
if((await provider.getNetwork()).chainId!==BigInt(manifest.chainId)) throw new Error('Wrong chain');
const verifierAddress=getAddress(config.riscZeroVerifier);
if((await provider.getCode(verifierAddress))==='0x') throw new Error('Verifier has no deployed code');
const verifier=new Contract(verifierAddress,[
  'function verify(bytes seal,bytes32 imageId,bytes32 journalDigest) view'
],provider);
// This MUST revert for invalid proof; returns successfully only when real verifier accepts the receipt.
await verifier.verify(receipt.seal,receipt.imageId,journalDigest);
const dao=getAddress(manifest.dao);
if((await provider.getCode(dao))==='0x') throw new Error('DAO is not deployed');
const snapshotInterface=new Interface([
  'function submitVerifiedSnapshot(uint256 proposalId,bytes journal,bytes seal)'
]);
const calldata=snapshotInterface.encodeFunctionData('submitVerifiedSnapshot',[
  BigInt(manifest.proposalId),receipt.journal,receipt.seal
]);
const tx={chainId:manifest.chainId,to:dao,value:'0',data:calldata,
  method:'submitVerifiedSnapshot(uint256,bytes,bytes)',proposalId:manifest.proposalId,
  merkleRoot:manifest.merkleRoot,imageId:receipt.imageId,journalDigest};
fs.writeFileSync('output/submission-transaction.json',JSON.stringify(tx,null,2)+'\n');
// Compatible shape for Safe Transaction Builder's single-contract-call import.
const safeBatch={version:'1.0',chainId:manifest.chainId,
  createdAt:Date.now(),meta:{name:`IPOR governance proof proposal ${manifest.proposalId}`,description:'Submit a cryptographically verified voting snapshot',txBuilderVersion:'1.0.0'},
  transactions:[{to:dao,value:'0',data:calldata}]};
fs.writeFileSync('output/safe-transaction-batch.json',JSON.stringify(safeBatch,null,2)+'\n');
const hashes={};
for(const f of ['snapshot.json','manifest.json','tree.json','voter-proofs.json','receipt.json','submission-transaction.json','safe-transaction-batch.json']){
  hashes[f]='0x'+crypto.createHash('sha256').update(fs.readFileSync('output/'+f)).digest('hex');
}
fs.writeFileSync('output/artifact-hashes.json',JSON.stringify(hashes,null,2)+'\n');
console.log('Real receipt verified by configured on-chain verifier; submission transaction packaged. No transaction broadcast.');
