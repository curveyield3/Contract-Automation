import fs from 'node:fs';
import path from 'node:path';
import { AbiCoder, Contract, JsonRpcProvider, getAddress, getBytes, keccak256 } from 'ethers';

const configPath = process.env.CONFIG_PATH || 'config/protocol.json';
const proposalIdString = process.env.PROPOSAL_ID;
const rpcUrl = process.env.ETH_RPC_URL;
if (!rpcUrl || !proposalIdString || !/^\d+$/.test(proposalIdString)) {
  throw new Error('ETH_RPC_URL and decimal PROPOSAL_ID are mandatory');
}
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
const clean = addr => getAddress(addr);
const dao = clean(config.dao), registry = clean(config.registry);
const vault = clean(config.vaultShareToken), safe = clean(config.safe);
const morphoBlue = clean(config.morphoBlue);
const morphoMarketIds = config.morphoMarketIds || [];
const curveAmmAddresses = (config.curveAmmAddresses || []).map(clean);
const chainId = BigInt(config.chainId), proposalId = BigInt(proposalIdString);
const provider = new JsonRpcProvider(rpcUrl, undefined, { staticNetwork: false });
const actualNetwork = await provider.getNetwork();
if (actualNetwork.chainId !== chainId) throw new Error('RPC chain ID does not match config');

// This hash layout MUST exactly match the DAO contract and the zkVM guest.
const configHash = keccak256(AbiCoder.defaultAbiCoder().encode(
  ['uint256','address','address','address','address','address','bytes32[]','address[]','bytes32'],
  [chainId,dao,registry,vault,safe,morphoBlue,morphoMarketIds,curveAmmAddresses,config.adapterVersionHash]
));
const daoContract = new Contract(dao, [
  'function getSnapshotMeta(uint256 proposalId) view returns (uint64 snapshotBlock, bytes32 snapshotBlockHash, bytes32 configHash)'
], provider);
const meta = await daoContract.getSnapshotMeta(proposalId);
if (meta.configHash.toLowerCase() !== configHash.toLowerCase()) {
  throw new Error('Market/registry/vault configuration differs from the DAO snapshot commitment');
}
const blockNumber = Number(meta.snapshotBlock);
const latest = await provider.getBlockNumber();
if (!Number.isSafeInteger(blockNumber) || blockNumber <= 0 || blockNumber > latest) {
  throw new Error('Invalid or future snapshot block');
}
if (latest - blockNumber < (config.minimumConfirmations ?? 64)) {
  throw new Error('Snapshot block has not met the configured confirmation threshold');
}
const block = await provider.getBlock(blockNumber);
if (!block || block.hash.toLowerCase() !== meta.snapshotBlockHash.toLowerCase()) {
  throw new Error('Snapshot block hash does not match DAO commitment');
}
const read = { blockTag: blockNumber };
const roster = new Contract(registry, [
  'function voterCount() view returns (uint256)',
  'function voterAt(uint256 index) view returns (address)',
  'function isEligibleAt(address voter,uint256 proposalId) view returns (bool)'
], provider);
const token = new Contract(vault, ['function balanceOf(address holder) view returns (uint256)'], provider);
const morpho = new Contract(morphoBlue, [
  'function position(bytes32 id,address user) view returns (uint256 supplyShares,uint128 borrowShares,uint128 collateral)',
  'function idToMarketParams(bytes32 id) view returns (address loanToken,address collateralToken,address oracle,address irm,uint256 lltv)'
], provider);
const curves = curveAmmAddresses.map(address => new Contract(address, [
  'function get_sum_xy(address user) view returns (uint256[2])',
  'function collateral_token() view returns (address)'
], provider));

// Supported here: vault shares as Morpho/Curve collateral, not loan-asset deposits.
for (const id of morphoMarketIds) {
  if (!/^0x[0-9a-fA-F]{64}$/.test(id)) throw new Error('Invalid Morpho market ID');
  const params = await morpho.idToMarketParams(id, read);
  if (clean(params.collateralToken) !== vault) throw new Error(`Morpho market ${id} does not use vault shares as collateral`);
}
for (let j=0; j<curves.length; j++) {
  // Implement a version-specific collateral-token adapter before enabling an unsupported LLAMMA.
  const collateral = await curves[j].collateral_token(read);
  if (clean(collateral) !== vault) throw new Error(`Curve AMM ${curveAmmAddresses[j]} has different collateral`);
}

const voterCount = await roster.voterCount(read);
if (voterCount > 1000000n) throw new Error('Refusing unexpectedly large voter roster');
const voters = [];
const seen = new Set();
for (let i=0n; i<voterCount; i++) {
  const user = clean(await roster.voterAt(i, read));
  if (seen.has(user)) throw new Error('Duplicate registered voter address');
  seen.add(user);
  if (user === safe) continue; // Safe is never included in the community numerator.
  const eligible = await roster.isEligibleAt(user, proposalId, read);
  const direct = eligible ? await token.balanceOf(user, read) : 0n;
  const morphoParts = eligible ? await Promise.all(morphoMarketIds.map(id => morpho.position(id, user, read))) : [];
  const curveParts = eligible ? await Promise.all(curves.map(c => c.get_sum_xy(user, read))) : [];
  const morphoValues = morphoParts.map(p => BigInt(p.collateral));
  const curveValues = curveParts.map(p => BigInt(p[1]));
  const amount = BigInt(direct) + morphoValues.reduce((a,b)=>a+b,0n) + curveValues.reduce((a,b)=>a+b,0n);
  voters.push({user, eligible, direct: String(direct), morpho: morphoValues.map(String), curve: curveValues.map(String), baseWeight: String(eligible ? amount : 0n)});
}
fs.mkdirSync('output', { recursive: true });
const snapshot = {
  schemaVersion:1, chainId:String(chainId), proposalId:String(proposalId),
  dao, registry, vault, safe, morphoBlue,
  morphoMarketIds, curveAmmAddresses, adapterVersionHash:config.adapterVersionHash,
  configHash, snapshotBlock:blockNumber, snapshotBlockHash:block.hash,
  voterCount: String(voterCount), voters
};
fs.writeFileSync(path.join('output','snapshot.json'), JSON.stringify(snapshot,null,2) + '\n');
console.log(`Collected ${voters.length} non-Safe registered voters at block ${blockNumber}`);
