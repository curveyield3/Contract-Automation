#!/usr/bin/env bash
set -euo pipefail
# An actual guest + host prover must be deployed here before this can succeed.
# It MUST prove authenticated historical state + complete roster enumeration,
# use the same on-chain governance weighting rules, and produce an on-chain-verifiable seal.
if [[ ! -x ./prover/bin/wbtc-ipor-prover ]]; then
  echo 'FATAL: real RISC Zero Steel guest/host prover is not yet integrated at prover/bin/wbtc-ipor-prover.' >&2
  echo 'No validity proof can be generated from unauthenticated JSON or a fake/mock receipt.' >&2
  exit 1
fi
if [[ "${RISC0_DEV_MODE:-0}" != "0" ]]; then
  echo 'FATAL: RISC0_DEV_MODE is not permitted for production submission bundles' >&2
  exit 1
fi
./prover/bin/wbtc-ipor-prover --input output/snapshot.json --manifest output/manifest.json --output output/receipt.json
[[ -s output/receipt.json ]] || { echo 'FATAL: prover returned no receipt' >&2; exit 1; }
