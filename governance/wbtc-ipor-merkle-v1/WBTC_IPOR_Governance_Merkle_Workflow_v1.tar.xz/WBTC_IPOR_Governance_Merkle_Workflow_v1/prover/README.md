# Required RISC Zero proving integration

The real authenticated-state zkVM program is not supplied because the deployment contracts, storage semantics and target chain are not defined. Add an actual RISC Zero Steel guest + host prover to this path after those are finalized. The executable must appear as `prover/bin/wbtc-ipor-prover` and accept the CLI flags documented in the project README.

The proving program must cryptographically authenticate the complete registry, every eligible voter, Morpho/Curve deposited vault-share balances, inactivity status, exact Safe 15% and the resulting Merkle root against one DAO-pinned historical block hash. It must commit the 11-field ABI journal documented in README and return a real RISC Zero seal. It must reject missing voters, unsupported markets, fabricated balance witnesses, modified configuration and any inconsistent block state. Neither an ordinary Merkle proof nor re-running the JavaScript calculation constitutes this proof.

This requirement deliberately **blocks** the workflow rather than falsely claiming a validity proof was generated.
