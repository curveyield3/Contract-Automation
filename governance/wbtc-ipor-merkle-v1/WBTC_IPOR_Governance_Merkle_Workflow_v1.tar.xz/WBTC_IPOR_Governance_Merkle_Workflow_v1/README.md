# WBTC IPOR Aragon DAO — Governance Merkle Workflow v1

**Status: integration scaffold, not a production proof generator.** The workflow, snapshot reader, Merkle tree, and submission packager are written. A fully authenticated RISC Zero Steel guest/host prover, the exact registry/DAO ABI, market-specific adapters, deployed verifier, and deployment addresses do **not** exist in this package. The workflow intentionally **stops with failure at the prover stage** until that implementation is supplied. It never labels a merely generated Merkle tree as a verified voting-power commitment.

## Operational requirement and repository placement

This is a **new** workflow for an unimplemented DAO voting system, not an extra audit/checking workflow for `curveyield3/Contract-Automation` or `curveyield3/Audit-Controller`. It fills a missing operational capability: generating ZK validity receipts and user-vote distribution proofs that Aragon cannot calculate economically for a large registered-voter set. No existing workflow in the available `curveyield3/Smart-Contracts` search was identified as already performing this function. **No GitHub repository was changed.** Import into the selected DAO source repository when the relevant contracts and prover are available, preferably through a dedicated branch.

## Intended sequence

1. User creates a **pending** Merkle-mode proposal on chain. DAO freezes a canonical historical block, its hash, the configuration hash, the proposal ID and the eligible voter registration state. Proposal's voting period **does not begin yet**.
2. Anyone runs `WBTC IPOR governance Merkle validity preparation` via `workflow_dispatch`, entering the pending proposal ID.
3. GitHub Actions reads from an archive RPC at the committed block. It enumerates each registered address and checks activation, self-delegation and inactivity according to the DAO's historic eligibility interface.
4. It adds direct vault-share holdings, **only whitelisted Morpho vault-share collateral**, and **only whitelisted CurveLend vault-share collateral**. It excludes the Safe's asset holdings from the community share total. It must not double-count vault tokens held by lending custodians, and must not blindly count Morpho's `supplyShares` as vault collateral.
5. It builds a deterministic OpenZeppelin Standard Merkle Tree containing domain-separated leaves `(chainId, dao, proposalId, snapshotBlock, voter, weight)` and writes individual proof paths.
6. A Rust RISC Zero Steel guest must prove from authenticated historical Ethereum state: full roster, eligibility, market configuration and exact balances, correct per-person and total weights, correct Safe percentage, and the exact produced root.
7. The host generates a real on-chain-verifiable RISC Zero receipt. The packager checks the receipt journal exactly against the root and on-chain metadata, then verifies its `seal` using the configured deployed RISC Zero verifier. **Mock receipts / dev mode are forbidden.**
8. Actions uploads a bundle containing `snapshot.json`, `manifest.json`, `tree.json`, `voter-proofs.json`, `receipt.json`, `submission-transaction.json`, `safe-transaction-batch.json`, and `artifact-hashes.json`. Submission is **manual** by default; no wallet key and no chain writes from GitHub.
9. The DAO's `submitVerifiedSnapshot(proposalId,journal,seal)` must itself verify receipt, trusted guest image ID, exact proposal/chain/block hash/config hash, quorum denominator and root. It must activate voting **only after successful verification**.

## Voting and calculation requirements

- `activateVotingPower()` combines registration and ERC20 self-delegation in **one write transaction**. Caller must be registered/delegated at snapshot block. An external registry cannot call ordinary `delegate()` on behalf of an unrelated ERC20 holder; implement token-native activation or a valid `delegateBySig()` flow.
- Shares held by nonactivated or expired users do **not** contribute to total voting weight or quorum.
- Inactivity triggers only if **both** (a) three calendar months since the close of the first eligible missed proposal in the current streak, and (b) at least two eligible closed proposals missed without a vote. A vote resets the streak. Parameters governable by Aragon; evaluation is in frozen historical state.
- Voting period 14 days; quorum 25% of total activated snapshot weight; approval threshold 67%; 10% proposal-creation threshold; 0.001 vault-share deposit, refundable absent majority spam designation. These are on-chain plugin settings, not independently configured in this workflow.
- **Exact Safe 15% without rounding:** community members' underlying base weights are multiplied by **85**; Safe weight is `15 * sum(community base weights)`; total is `100 * sum(community base weights)`. Exclude the Safe's own asset holdings from the community numerator.
- Support vault shares as **collateral** in approved Morpho Blue markets and approved CurveLend AMMs. Lending vault shares as the **loan asset** or via nested wrapper positions requires new audited accounting adapters before enabling; do not double-count borrower and lender claims.
- ERC20 checkpoint totals are not automatically the activated-vote total. The proven registry, balances and sources determine the denominator.
- Merkle snapshot commits to one historical block. Do not calculate over drifting chain state.

## Mandatory on-chain interfaces still to be implemented

`getSnapshotMeta(uint256 proposalId) -> (uint64 snapshotBlock, bytes32 snapshotBlockHash, bytes32 configHash)` on the Aragon governance plugin.

`voterCount() -> uint256`, `voterAt(uint256) -> address`, and `isEligibleAt(address,uint256 proposalId) -> bool` on the historical-readable voter registry.

`submitVerifiedSnapshot(uint256 proposalId,bytes journal,bytes seal)` on the governance plugin. This call must verify the RISC Zero proof against a pinned image ID and fully validate every journal statement against stored proposal data.

The **configuration hash layout** must match the `AbiCoder` call in `scripts/collect-snapshot.mjs` and the guest program. A contract upgrade changing layout requires an explicit new version/hash.

## Prover contract / guest protocol

`prover/bin/wbtc-ipor-prover --input output/snapshot.json --manifest output/manifest.json --output output/receipt.json` (executable not supplied; intentionally mandatory).

`receipt.json` required keys:

```json
{
  "seal": "0x<real RISC Zero seal bytes>",
  "imageId": "0x<32-byte program image identifier>",
  "journal": "0x<ABI-encoded journal bytes>"
}
```

Journal schema (exact types and order):

```
abi.encode(
  uint256 chainId,
  address dao,
  uint256 proposalId,
  uint256 snapshotBlock,
  bytes32 snapshotBlockHash,
  bytes32 configHash,
  bytes32 merkleRoot,
  uint256 totalVotingWeight,
  uint256 communityBaseWeight,
  address safe,
  uint256 safeWeight
)
```

The guest must recompute all these values from **authenticated state**, including the full sorted Merkle tree, not merely accept `snapshot.json` or `manifest.json` as trusted witnesses. Steel historical view calls can be used if their authentication and target-chain support are implemented correctly. The authenticated block commitment must be compared against the block hash stored in the proposal. The guest image ID must be fixed by the DAO, not selected by the workflow operator. The verifier must be a production verifier, not a mock.

## Configuration and secrets

Copy `config/protocol.example.json` to `config/protocol.json` after deployment. Set addresses, market IDs, target chain ID, accepted guest image ID, deployed RISC Zero verifier and required confirmation count. Register the repository secret `GOVERNANCE_ARCHIVE_RPC_URL` with an archive-capable RPC for the target chain. Prover service credentials, if needed, belong in GitHub Actions secrets with strict scopes.

Do not check in private keys, Safe signing secrets, or RPC API tokens. Only read-only GitHub permissions are needed. Source & workflow actions should be pinned to reviewed hashes before production use. The repo default branch should be protected from unreviewed changes to the guest and workflow.

**Important:** The included `collateral_token()` CurveLend adapter is an interface assumption. Before enabling any Curve market, check its actual deployed version and replace the adapter if needed; an unsupported market must cause failure, not silent omission. Market-list modifications and proof-image changes require Aragon voting and affect **new** proposals only.

## Deliverable bundle

- `output/manifest.json`: snapshot metadata, Merkle root, Safe weight, community and total weight.
- `output/voter-proofs.json`: inclusion proof for every registered non-Safe voter plus the Safe.
- `output/receipt.json`: *only* a real validity proof can populate this.
- `output/submission-transaction.json`: exact `to`, `data`, `value`, chain and intended proposal identifiers.
- `output/safe-transaction-batch.json`: importable single-transaction bundle for review in Safe Transaction Builder; confirm compatibility with actual deployed Safe UI.
- `output/artifact-hashes.json`: SHA-256 checksums of the bundle.

## Security constraints

- GitHub is an **untrusted prover/publisher**, not a governance administrator.
- No automatic submission and no repo-write GitHub token.
- No proof verification bypass; `prove.sh` fails if real prover is not installed.
- Do not treat a successful GitHub Actions run as on-chain acceptance or DAO proposal activation.
- Only an actual successful transaction in the DAO proves that the snapshot was accepted.
- Version-pinned direct JavaScript dependencies are supplied; a reproducible `package-lock.json` still needs to be generated and reviewed in an online installation environment before production use. Network access prevented generating it while preparing this package.

Sources: https://dev.risczero.com/api/blockchain-integration/risc-zero-on-eth ; https://github.com/risc0/risc0-ethereum/blob/main/contracts/src/IRiscZeroVerifier.sol ; https://github.com/OpenZeppelin/merkle-tree ; https://docs.morpho.org/developers/contracts/blue/ ; https://docs.curve.finance/developer/integration/llamma/ .
