// SPDX-License-Identifier: UNLICENSED
pragma solidity 0.8.28;

/// @notice Existing Ethereum mainnet CurveYieldOmniRouter (not deployed by this package).
interface ICurveYieldOmniRouter {
    /// @notice Gross historical price: whole tokenOut per whole tokenIn, scaled by 1e18.
    function price_oracle(address tokenIn, address tokenOut) external view returns (uint256);
    function routeLength(address tokenIn, address tokenOut) external view returns (uint256);
    function getAmountOut(address tokenIn, address tokenOut, uint256 amountIn)
        external view returns (uint256 amountOut);
    function guardedMinOut(address tokenIn, address tokenOut, uint256 amountIn)
        external view returns (uint256 minimumNetOut);
    function swapExactInput(
        address tokenIn, address tokenOut, uint256 amountIn,
        uint256 minNetAmountOut, address recipient, uint256 deadline
    ) external returns (uint256 netAmountOut);
}
