// SPDX-License-Identifier: MIT
/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * dApp: https://curveyield.com & https://curveyield.org
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */
pragma solidity ^0.8.20;

/// @notice Capital-flow-neutral 15-day PPS APR tracker for master-owned children.
/// @dev Mirrors the vault's 16 daily / 5 recent samples. Units are internal,
///      minted on allocation and burned on deallocation, never transferable.
abstract contract ChildAPR15dV42 {
    struct Sample { uint40 timestamp; uint216 pps; }
    Sample[16] private daily;
    Sample[5] private recent;
    uint8 private dailyCount;
    uint8 private recentCount;
    uint8 private dailyNext;
    uint8 private recentNext;
    uint40 public lastAPRCheckpoint;
    uint40 public lastDailyAPRCheckpoint;
    uint256 public aprUnits;
    uint256 public lastValidAPR;
    bool public hasValidAPR;

    uint256 private constant WAD = 1e18;
    uint256 private constant WINDOW = 15 days;
    uint256 private constant MAX_WINDOW = 30 days;

    function _aprAssetBalance() internal view virtual returns (uint256);

    function _afterAllocationDeposit(uint256 amount, uint256 valueBefore) internal virtual {
        if (amount == 0) return;
        uint256 units = aprUnits;
        // Round shares up: inflows may never falsely increase PPS.
        uint256 minted = units == 0 || valueBefore == 0 ? amount
            : (amount * units + valueBefore - 1) / valueBefore;
        aprUnits = units + minted;
        _snapshot();
    }

    function _afterAllocationWithdraw(uint256 amount, uint256 valueBefore) internal virtual {
        uint256 units = aprUnits;
        if (amount != 0 && units != 0) {
            uint256 burned = valueBefore == 0 ? units
                : (amount * units + valueBefore - 1) / valueBefore;
            aprUnits = burned >= units ? 0 : units - burned;
            // Empty positions should not preserve stale APR for comparisons.
            if (aprUnits == 0) hasValidAPR = false;
        }
        _snapshot();
    }

    function _afterHarvest() internal virtual { _snapshot(); }

    function checkpointAPR() external { _snapshot(); }

    function _pps() internal view returns (uint256) {
        uint256 units = aprUnits;
        if (units == 0) return 0;
        return _aprAssetBalance() * WAD / units;
    }

    function _snapshot() internal {
        if (block.timestamp < uint256(lastAPRCheckpoint) + 4 hours || aprUnits == 0) return;
        uint256 pps = _pps();
        if (pps == 0 || pps > type(uint216).max) return;
        Sample memory s = Sample(uint40(block.timestamp), uint216(pps));
        recent[recentNext] = s;
        recentNext = (recentNext + 1) % 5;
        if (recentCount < 5) ++recentCount;
        lastAPRCheckpoint = uint40(block.timestamp);
        if (block.timestamp >= uint256(lastDailyAPRCheckpoint) + 1 days) {
            daily[dailyNext] = s;
            dailyNext = (dailyNext + 1) % 16;
            if (dailyCount < 16) ++dailyCount;
            lastDailyAPRCheckpoint = uint40(block.timestamp);
        }
        (bool ready, uint256 value) = _compute(pps);
        if (ready) { hasValidAPR = true; lastValidAPR = value; }
    }

    function getAPR() external view returns (uint256) { (, uint256 value) = _read(); return value; }
    function aprReady() external view returns (bool) { (bool ready,) = _read(); return ready; }
    function rate() external view returns (uint256) { (, uint256 value) = _read(); return value / 365 days; }

    function _read() private view returns (bool, uint256) {
        uint256 pps = _pps();
        return pps == 0 ? (false, 0) : _compute(pps);
    }

    function _compute(uint256 nowPps) private view returns (bool, uint256) {
        uint256 target = block.timestamp > WINDOW ? block.timestamp - WINDOW : 0;
        uint256 closest = type(uint256).max;
        uint256 startPps;
        uint256 startTime;
        for (uint256 i; i < dailyCount; ++i) {
            Sample memory s = daily[i];
            if (s.timestamp == 0 || s.timestamp >= block.timestamp || block.timestamp - s.timestamp > MAX_WINDOW) continue;
            uint256 distance = s.timestamp > target ? s.timestamp - target : target - s.timestamp;
            if (distance < closest) { closest = distance; startPps = s.pps; startTime = s.timestamp; }
        }
        if (startPps == 0) {
            uint256 count;
            for (uint256 i; i < recentCount; ++i) {
                Sample memory s = recent[i];
                if (s.timestamp == 0 || s.timestamp >= block.timestamp || block.timestamp - s.timestamp > MAX_WINDOW) continue;
                ++count;
                if (startTime == 0 || s.timestamp < startTime) { startPps = s.pps; startTime = s.timestamp; }
            }
            if (hasValidAPR && count < 5) return (true, lastValidAPR);
        }
        if (startPps == 0) return (hasValidAPR, lastValidAPR);
        if (nowPps <= startPps) return (true, 0);
        // APR is deliberately unsigned like the original vault APR.
        uint256 gainWad = (nowPps - startPps) * WAD / startPps;
        return (true, gainWad * 365 days / (block.timestamp - startTime));
    }
}
