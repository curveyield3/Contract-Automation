// SPDX-License-Identifier: MIT
/**
 * @title CurveYield System Component
 * @notice CurveYield is a decentralized NGO building optimized DeFi systems for the good of all.
 *
 * @dev CurveYield integrates specialized AMM infrastructure, tokenized yield strategies, credit
 * markets, and protocol-owned liquidity into a unified, capital-efficient liquidity stack governed
 * by an open, international DAO community.
 *
 * Protocol operations are enhanced by cross-chain bridging and messaging, MEV capture systems,
 * off-chain to on-chain automation, and peer-to-peer data networks.
 *
 * This contract is one component of the CurveYield system.
 *
 * CurveYield uses proven DeFi primitives where possible and adds targeted coordination and
 * capital-efficiency-enhancing contracts where needed. Users and integrators must review
 * CurveYield documentation before use.
 *
 * Learn more:
 * dApp: https://curveyield.com & https://curveyield.org
 *
 * Decentralized links may have limited or delayed availability during periods of high network activity:
 * https://curveyield.eth.limo
 * https://curveyield.dao
 *
 * Note: curveyield.dao may require a Brave Browser or an Unstoppable Domains browser plugin to use.
 */
pragma solidity ^0.8.20;

import "./StrategyConvexBoostHubStakingV5.sol";
import "./ChildAPR15dV42.sol";

/// @notice The unchanged BoostHub staking adapter with independent 15-day APR observations.
contract StrategyBoostHubChildV42 is StrategyConvexBoostHubStakingV5, ChildAPR15dV42 {
    constructor(
        address staking,
        Addresses memory addresses_,
        FeeSettings memory fees,
        uint256 lockDuration,
        uint256 minWantOutput
    ) StrategyConvexBoostHubStakingV5(staking, addresses_, fees, lockDuration, minWantOutput) {}

    function _aprAssetBalance() internal view override returns (uint256) { return balanceOf(); }
    function _afterAllocationDeposit(uint256 amount, uint256 beforeValue)
        internal override(BaseAllToWantBoostHubV5, ChildAPR15dV42)
    { ChildAPR15dV42._afterAllocationDeposit(amount, beforeValue); }
    function _afterAllocationWithdraw(uint256 amount, uint256 beforeValue)
        internal override(BaseAllToWantBoostHubV5, ChildAPR15dV42)
    { ChildAPR15dV42._afterAllocationWithdraw(amount, beforeValue); }
    function _afterHarvest() internal override(BaseAllToWantBoostHubV5, ChildAPR15dV42) {
        ChildAPR15dV42._afterHarvest();
    }
}
